#include<iostream>
using namespace std;

class node
{
	node *next;
	int data;
	
	
	public:
			friend class chain;
		
	
};


class chain
{
node *G[100];
int key,value;

public:
	int n;
chain()
{
cout<<"enter the no  of elements in list"; cin>>n;

      for(int i=0;i<n;i++)
     {
	G[i]=NULL;
	
	}	
	
}
node *assign(int value)
		{
			node * newnode =new node;
			newnode->data= value;
			newnode->next=NULL;
			
			return newnode;
			
		}
void accept()
{
	int data;

	
		cout<<"enter the data";
		cin>>data;
		
		key= data%n;
		node *newnode =assign(data);
		
		if(G[key]==NULL)
		{
			G[key]=newnode;
		//	cout<<"head is create with data"<<data<<endl;
	
		}
		else
		{
			node * move;
			move=G[key];
			cout<<"data is inserted at chain"<<move->data<<endl;
			newnode->next=move;
			G[key]=newnode;
			cout<<"inserted data is "<<newnode->data<<endl;
			
		    	cout<<endl;
		}
		
		
	
		
}

	void find()
	{
		int k,count=0;
		cout<<"enter the value to be searched";
		cin>>k;
		
		int key1= k%n;
		node *move= G[key1];
		while(move!=NULL)
		{
			if(move->data==k)
			  {
			  	cout<<"data found at"<<key1<<"with key ";
			  return ;
			  }
			move=move->next;
		}
		cout<<"data not present";
	return ;	
		
	}
	void display()
	{
		node *move=NULL;
		for(int i=0;i<n;i++)
		{
		move=G[i];
		while(move!=NULL)
		{
			cout<<move->data<<"-->";
			move=move->next;
		}
		cout<<endl;	
		}	
	}
	
	void delete1()
	
	{
		int del;
		cout<<"	ENTER THE DATA TO BE DELETED  ";
		cin>>value;
		
		key=value%n;
		
		node *move=G[key];
		cout<<"the statting of chain "<<move->data<<endl;
		node *temp=NULL;
		
		if(move->data==value)
		{
			//	cout<<"inside the if "<<endl;
			temp=move->next;
			move->next=NULL;
			delete move;
			G[key]=temp;
			return ;
			
		}
		
		while(move!=NULL && move->data!=value )
		{
			temp=move;
		   move=move->next;
		   
		}
		cout<<"the temp->data"<<temp->data<<endl;
		if(temp->next->data==value)
		{
		
			temp->next=move->next;
			move->next=NULL;
			delete move;
			
			
		}
		
		
	}
	
void search()
{
	
	
	
	
}
	
};

int main()
{
	int ch,count=0;
	chain c;
	do
	{
		
		cout<<"1.insert \n 2. display \n3.delete \n 4.find\n  0.exit";
		cin>>ch;
		
		
		switch(ch)
		{
			case 1:
				if(count==c.n)
				cout<<"table is full!!!!"<<endl<<endl;
				else
				{
					if(count!=c.n)
				{
					c.accept();
					  count++;
					 // c.display();
				}
				}
				
					break;
				case 2:
					c.display();
					break;
			
			case 3:
				c.delete1();
				break;
				case 4:
					c.find();
					break;
			
		}
	}while(ch!=0);
	
	
}



