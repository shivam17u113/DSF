//============================================================================
// Name        : EXPRE.cpp
// Author      : shivam parve
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class treenode
{
private:
	char exp;
	treenode *left;
	treenode *right;

public:
	friend class stack;
	treenode()
{
		exp='0';
		left= right= NULL;

}

	treenode* assign( char ch, treenode * l, treenode *r)
	{
		treenode *item= new treenode;
		item->exp=ch;
		item->left=l;
		item->right=r;

		return item;
	}




};

class node
{
public:
	friend class stack;
private:
	treenode *data;
	node*next;
};

class stack
{
private:
	node* top;

public:
	stack()
	{
			top=NULL;
	}
void push(treenode *temp)
   {
			node *newnode = new node;
			newnode->data=temp;
			newnode->next=NULL;

if(top==NULL)
		{
		top=newnode;

		}

else
		{
		newnode->next=top;
		top=newnode;

		}
   }

treenode *pop()
{
	node *temp;
	temp=top;
	top=temp->next;

	treenode *tn;
	tn=NULL;
	tn= temp->data;

	delete temp;

	return tn;
}

void inorder(treenode *root)
{
	if(root!=NULL)
	{
		inorder(root->left);
		cout<<root->exp;
		 inorder(root->right);
	}
}
void preorder( treenode *root)
{
	
	if(root!=NULL)
	{
	
	cout<<root->exp;
	preorder(root->left);
	preorder(root->right);
	}	
}
void postorder( treenode *root)
{
	
	if(root!=NULL)
	{
	

	postorder(root->left);
	postorder(root->right);
		cout<<root->exp;
	}		
else
return ;
	
	
}
treenode *returntop()
{
	
	return top->data;
	cout<<" top returnend  " <<top->data;
}


void display()
{
	
	
	cout<<top->data->exp;
	cout<<(top->data->left)<<endl;
   cout<<(top->data->right);	
}

};


int main()
{

int i=0;
	char ch;
int ch1;
	stack s;
	treenode *tn,*r,*l,t;
	
	string str;
	cout<<"\n enter the expression   ";
	cin>>str;

	while(str[i]!='\0')
	{
		ch=str[i];

		if(ch != '+' && ch != '-' && ch != '/' && ch != '*') 
		{
			tn= t.assign(ch,NULL,NULL);
			s.push(tn);
   
		}
		else 
		{
			r=s.pop();
			l=s.pop();
			tn= t.assign(ch,l,r);
			s.push(tn);
       
		}
i++;
}
		

	

treenode *move;
move=s.returntop();
cout<<"     "<<endl;


do
{
	cout<<"\n 1. inorder \n 2. preorder \n 3. postorder  \n 0.exit   ";
	cin>>ch1;
	switch(ch1)
	{
		case 1:
			cout<<"\n inorder expression    ";
			s.inorder(move);
			break;
		case 2:
			cout<<"\n preorder expression   ";
			s.preorder(move);
				break;
		case 3:
			cout<<"\n pst order expression    ";
					s.postorder(move);
					break;
		
		
	}
	
}while(ch1!=0);


	return 0;
}



// output
/*
enter the expression   ab+c*d-


 1. inorder
 2. preorder
 3. postorder
 0.exit   1

 inorder expression    a+b*c-d
 1. inorder
 2. preorder
 3. postorder
 0.exit   2

 preorder expression   -*+abcd
 1. inorder
 2. preorder
 3. postorder
 0.exit   3

 pst order expression    ab+c*d-
 1. inorder
 2. preorder
 3. postorder
 0.exit   0

--------------------------------
Process exited after 25.37 seconds with return value 0
Press any key to continue . . .


*/
































