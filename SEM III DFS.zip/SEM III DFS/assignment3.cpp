#include<iostream>
using namespace std;

class node
{
	node *left;
	node *right;
	int data;
	public:
	friend class BST;	
	
};

class BST
{
	node *top;
	
	public:
		
		BST()
		{
			top=NULL;
			
		}
		
		void insert(int value)
		{
			node *newnode= new node;
			newnode->left=NULL;
			newnode->right=NULL;
			newnode->data=value;
			
			if(top==NULL)
			{
				top=newnode;
					
			}
			else
			{
				node *temp,*move;
				temp=top;
			while(temp!=NULL)
			{
				move=temp;
				if(newnode->data<temp->data)
				temp=temp->left;
				
				else
				temp=temp->right;
				}	
				if(newnode->data<move->data)
				move->left=newnode;
				else
				move->right=newnode;
				
				
			}
	
		}
		
	void inorder( node *top)
	{
		if(top!=NULL)
		{
		inorder(top->left);
		cout<<top->data<<"\t";
		inorder(top->right);	
			
			
		}	
	}
	
	node *returntop()
	{
		return top;
	}
	int height(node *temp)
	{
		if(temp==NULL)
		return 0;
		

		else
		{
			int l_h=1+height(temp->left);
			int r_h=1+height(temp->right);
			
			
			if(l_h>r_h)
			return (l_h);
			else
			return (r_h);
			
		}
		
		
	
	}
	void print(node *top)
	{
		cout<<top->data;
		cout<<top->left->data;
		cout<<top->right->data;
	
	}
	
	int countnodes(node *top)	
	
	{
		
		if(top==NULL)
		return 0;
		else
		return (countnodes(top->left) + countnodes(top->right) +1 );
		
		
	}

	void minimum(node *top)
{

node *root;
root=top;

while(root->left!=NULL)
{
root=root->left;


}
cout<<root->data;


}

};

int main()
{
	int h,c,val,ch,ch1,v;
	node *top;
	top=NULL;
	BST b1;

cout<<" \n\n please note if you want to stop then please enter 0  \n\n";
do
{
cout<<"\n enter the next value    ";
cin>>ch;

if(ch==0)
break;
b1.insert(ch);
}while(ch!=0);

top=b1.returntop();


do
{
cout<<"\n 1. insert the newnode \n 2. height of tree \n 3.no of nodes in longest path \n 4.inorder \n 5. minimum data in tree";
cin>>ch1;
switch(ch1)
{
case 1:
cout<<"\n enter the data   "; cin>>v;
b1.insert(v);
cout<<endl<<endl;
break;
case 2:
h=	b1.height(top);
cout<<" height of the tree   "<<h;
cout<<endl<<endl;
break;
case 3:
c=1+b1.height(top);
cout<<" no of nodes in longest path  "<<c;
cout<<endl<<endl;
break;

case 4:
b1.inorder(top);
break;
case 5:
b1.minimum(top);
break;


}




}while(ch1!=0);

	cout<<"\n\n  ";
	






	return 0;
}









