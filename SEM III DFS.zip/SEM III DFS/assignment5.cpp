
// Name        : Assignment5
//                  graph rtaversal dfs 
// Author      : shivam parve
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================



#include <iostream>
#include<iomanip>
#include<stack>
#include<vector>
using namespace std;

class graph
{
	int i,j,v;
	int arr[100][100];
	int visited [100];


public:
	graph()
{
		cout<<"enter the no of nodes  "; cin>>v;
		arr[v][v];
         visited[v];

         //for(int k=0; k<v;k++)
        //	 visited[v]=0;

}
	void accept()
	{
		for(i=0; i<v;i++)
			{

				for(j=0;j<v;j++)
				{
					if(i!=j)
					{
						cout<<"\n enter 1 if vertex  " <<i<<"  is adjacent to  "<<j<<" other wisw 0:";
						cin>>arr[i][j];
						//arr[j][i]=arr[i][j];
					}
					else
						arr[i][j]=0;

				}

			}



	}

	void print()
	{
	//	cout<<"\n\n"<<setw(4)<<"";
            cout<<"     ";
		for(i=0;i<v;i++)
		{
			cout<<setw(3)<<"["<<i<<"]";


		}
		cout<<"\n\n";

		for(i=0;i<v;i++)
		{
			cout<<setw(3)<<"["<<i<<"]";
			for(j=0;j<v;j++)
			{
				cout<<setw(4)<<arr[i][j];

			}
			cout<<"\n\n";

		}



	}
	void dfs(int i)
{
	
	
	int j;
	cout<<"\n"<<i;
	visited[i]=1;
	for(j=0;j<v;j++)
	{
		if(visited[j]==0 && arr[i][j]==1)
		   dfs(j);
	}
	
	
	
}
   void equate()
   {
   	for( int j=0;j<v;j++)
   	visited[j]=0;
   }




};

int main()
{
	graph g;
	g.accept();
	
	g.print();
 cout<<"\n\n dfs  ";
 g.equate();
 g.dfs(0);
	return 0;
}

/*enter the no of nodes  4

 enter 1 if vertex  0  is adjacent to  1 other wisw 0:0

 enter 1 if vertex  0  is adjacent to  2 other wisw 0:1

 enter 1 if vertex  0  is adjacent to  3 other wisw 0:1

 enter 1 if vertex  1  is adjacent to  0 other wisw 0:0

 enter 1 if vertex  1  is adjacent to  2 other wisw 0:1

 enter 1 if vertex  1  is adjacent to  3 other wisw 0:1

 enter 1 if vertex  2  is adjacent to  0 other wisw 0:0

 enter 1 if vertex  2  is adjacent to  1 other wisw 0:1

 enter 1 if vertex  2  is adjacent to  3 other wisw 0:0

 enter 1 if vertex  3  is adjacent to  0 other wisw 0:1

 enter 1 if vertex  3  is adjacent to  1 other wisw 0:1

 enter 1 if vertex  3  is adjacent to  2 other wisw 0:0
       [0]  [1]  [2]  [3]

  [0]   0   0   1   1

  [1]   0   0   1   1

  [2]   0   1   0   0

  [3]   1   1   0   0



 dfs
0
2
1
3
--------------------------------
Process exited after 16.08 seconds with return value 0
Press any key to continue . . .*/













































































































































